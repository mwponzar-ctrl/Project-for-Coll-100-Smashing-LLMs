(() => {
const $ = s => document.querySelector(s), KEY = 'many-lives-save';
const STATS = [['health','Health','#6ee7b7'],['happiness','Happiness','#fcd34d'],['smarts','Smarts','#93c5fd'],['looks','Looks','#f9a8d4'],['social','Social','#c4b5fd']];
const TRAITS = {Athletic:'Health declines slower',Bookworm:'Studying pays off more',Charming:'Socializing pays off more',Lucky:'Risks go your way more often',Frugal:'Lower living costs'};
const AVATARS = ['😀','😎','🧑‍🎤','🧑‍🚀','👩‍🔬','👨‍🍳','🧑‍🎨','🦸','🧙','🦊','🐱','🍊'];
const COLORS = ['#3b4a7a','#7a3b5a','#2f6b5a','#7a5a2f','#5a3b7a','#2f5a7a'];
const JOBS = [
 {t:'Cashier',pay:22e3,req:{}},{t:'Barista',pay:24e3,req:{}},
 {t:'Warehouse worker',pay:30e3,req:{health:40}},{t:'Salesperson',pay:42e3,req:{social:50}},
 {t:'Office assistant',pay:36e3,req:{smarts:45}},
 {t:'Nurse',pay:72e3,req:{smarts:65,college:1}},{t:'Software developer',pay:9e4,req:{smarts:70,college:1}}];
const E = (text, choices, o = {}) => ({text, choices, ...o});
const C = (t, fx, m, r) => ({t, fx, m, r});
const EVENTS = [
 E('You find a wallet with $200 inside.',[C('Return it',{happiness:4,social:2},'The owner is grateful.'),C('Keep the cash',{money:200,happiness:-2},'You pocket it. Guilt lingers.')]),
 E('Friends invite you to a big party.',[C('Go',{happiness:5,social:4},'Great night!',{p:.25,fx:{health:-6,money:-200},m:'Rough night. You overdid it.'}),C('Stay in and read',{smarts:3,happiness:1},'Quiet, productive evening.')]),
 E('You feel really sick.',[C('See a doctor',{money:-400},'Treated quickly.'),C('Tough it out',{health:-3},'You recover slowly.',{p:.4,fx:{health:-12},m:'It got much worse.'})]),
 E('An email says you won a prize. It wants your bank details.',[C('Click the link',{},'You send your details.',{p:.8,fx:{money:-1500,happiness:-5},m:'It was a scam.'}),C('Delete it',{smarts:1},'Wise move.')]),
 E('Your car breaks down.',[C('Pay for repairs',{money:-1200},'Fixed.'),C('Take the bus for a while',{happiness:-4,health:1},'Inconvenient but cheap.')]),
 E('An online course could boost your skills.',[C('Enroll ($500)',{money:-500,smarts:8},'You learn a lot.'),C('Skip it',{},'Maybe next year.')]),
 E('A friend wants you to run a marathon.',[C('Train and run',{health:6,happiness:3},'You finish proud!',{p:.2,fx:{health:-10},m:'You got injured.'}),C('Cheer from the sidelines',{social:2},'Fun day out.')]),
 E('You have a crush on someone.',[C('Ask them out',{social:6,happiness:10},'They said yes!',{p:.5,fx:{happiness:-6},m:'They said no. Ouch.'}),C('Stay quiet',{},'The moment passes.')],{min:18}),
 E('A $5 lottery ticket catches your eye.',[C('Buy it',{money:-5,happiness:-1},'Nothing this time.',{p:.04,good:1,fx:{money:50000,happiness:20},m:'YOU WON $50,000!'}),C('Walk away',{},'Keep your money.')]),
 E('Your boss announces layoffs.',[C('Plead your case',{},'You keep your job.',{p:.4,fx:{},m:'No luck. You are let go.',lose:1}),C('Take the severance',{money:3000},'You leave with $3,000.',{lose:1})],{job:1}),
 E('A weekend gig pays well.',[C('Work it',{money:1500,health:-2,happiness:-2},'Extra cash, tired body.'),C('Rest',{happiness:4},'Recharged.')]),
 E('Walking home late, someone demands your wallet.',[C('Hand it over',{money:-300,happiness:-4},'You lose $300.'),C('Fight back',{},'You scare them off!',{p:.5,fx:{health:-18,money:-300},m:'You got hurt and robbed.'})]),
 E('A post of yours goes viral.',[C('Embrace the fame',{social:8,happiness:5},'You get lots of new followers.'),C('Delete it',{happiness:-1},'Back to quiet life.')]),
 E('A distant relative leaves you money.',[C('Wonderful news',{money:5000,happiness:5},'+$5,000.')],{rare:1}),
 E('Your back aches constantly.',[C('Physical therapy ($800)',{money:-800,health:4},'It helps.'),C('Ignore it',{health:-6},'It gets worse.')],{min:40}),
 E('A coworker shares a hot stock tip.',[C('Invest $2,000',{money:-2000},'You invest.',{p:.5,good:1,fx:{money:4000},m:'The stock jumped! Net +$2,000.'}),C('Pass',{},'Playing it safe.')],{job:1}),
 E('A local shelter needs volunteers.',[C('Help out',{happiness:6,social:3},'It feels great.'),C('Not now',{},'Maybe later.')]),
 E('You can adopt a pet.',[C('Adopt ($400)',{money:-400,happiness:8},'A new best friend!'),C('Pass',{},'Not the right time.')])];
const ACTIONS = [
 {i:'🏋️',t:'Hit the gym',d:'+Health, +Happiness',fx:{health:6,happiness:2},m:'You worked out.'},
 {i:'📚',t:'Study',d:'+Smarts',fx:{smarts:6,happiness:-1},m:'You studied hard.',trait:['Bookworm','smarts']},
 {i:'🎉',t:'Go out with friends',d:'+Social, +Happiness · $50',fx:{social:4,happiness:5,money:-50},m:'You hung out with friends.',trait:['Charming','social']},
 {i:'🩺',t:'See a doctor',d:'+Health · $300',fx:{health:8,money:-300},m:'You got a checkup.'},
 {i:'🏖️',t:'Take a vacation',d:'+Happiness · $1,500',fx:{happiness:10,money:-1500},m:'You took a vacation.'},
 {i:'📈',t:'Invest $1,000',d:'70% gain, 30% loss',run:()=>{const w=chance(.7,1);const d=w?250:-300;s.money+=d;return `Your investment ${w?'grew':'shrank'}: ${w?'+':'−'}${money(Math.abs(d))}.`}}];
let s = null;
const clamp = v => Math.max(0, Math.min(100, v));
const money = n => (n < 0 ? '−' : '') + '$' + Math.abs(Math.round(n)).toLocaleString();
const has = t => s.traits.includes(t);
const chance = (p, good) => Math.random() < clamp(p * 100 + (has('Lucky') ? (good ? 10 : -10) : 0)) / 100;
const save = () => localStorage.setItem(KEY, JSON.stringify(s));
const log = (text, tone = '') => s.log.unshift({age: s.age, text, tone});
const eduLabel = () => s.school ? `College (${s.school} yr left)` : s.college ? 'College graduate' : 'High school graduate';
function fx(o) {
  const out = [];
  for (const k in o) {
    const v = o[k];
    if (k === 'money') { s.money += v; if (v) out.push((v > 0 ? '+' : '−') + money(Math.abs(v))); }
    else { const b = s[k]; s[k] = clamp(b + v); const d = s[k] - b; if (d) out.push((d > 0 ? '+' : '') + d + ' ' + k); }
  }
  return out.join(' · ');
}
function modal(html, buttons = []) {
  $('#box').innerHTML = html + buttons.map((b, i) => `<button data-i="${i}">${b.t}</button>`).join('');
  $('#modal').hidden = false;
  $('#box').querySelectorAll('button[data-i]').forEach(el => el.onclick = () => { $('#modal').hidden = true; buttons[el.dataset.i].cb?.(); });
}
const closeBtn = [{t:'Continue', cb: () => render()}];

function create() {
  const c = {name:'', av:AVATARS[0], color:COLORS[0], traits:[]};
  const draw = () => {
    $('#app').innerHTML = `<section class="card create"><h1>Design your life</h1><p class="mut">You turn 18 with $5,000, a family home and a lot of choices ahead.</p>
    <label for="nm">Your name</label><input id="nm" maxlength="24" placeholder="e.g. Arjun Mehta" value="${c.name}">
    <label>Appearance</label><div class="grid">${AVATARS.map(a => `<button data-av="${a}" class="${a === c.av ? 'sel' : ''}">${a}</button>`).join('')}</div>
    <div class="grid" style="margin-top:8px">${COLORS.map(x => `<button data-col="${x}" class="${x === c.color ? 'sel' : ''}" style="background:${x}" aria-label="Color ${x}">&nbsp;&nbsp;</button>`).join('')}</div>
    <label>Pick up to 2 traits</label><div class="grid">${Object.keys(TRAITS).map(t => `<button data-tr="${t}" class="${c.traits.includes(t) ? 'sel' : ''}" title="${TRAITS[t]}">${t} <small class="mut">· ${TRAITS[t]}</small></button>`).join('')}</div>
    <button class="primary age" id="go" ${c.name.trim() ? '' : 'disabled'}>Start my life</button>
    ${localStorage.getItem(KEY) ? '<button class="ghost age" id="cont">Continue saved life</button>' : ''}</section>`;
    $('#nm').oninput = e => { c.name = e.target.value; $('#go').disabled = !c.name.trim(); };
    document.querySelectorAll('[data-av]').forEach(b => b.onclick = () => { c.av = b.dataset.av; draw(); });
    document.querySelectorAll('[data-col]').forEach(b => b.onclick = () => { c.color = b.dataset.col; draw(); });
    document.querySelectorAll('[data-tr]').forEach(b => b.onclick = () => { const t = b.dataset.tr; c.traits = c.traits.includes(t) ? c.traits.filter(x => x !== t) : [...c.traits, t].slice(-2); draw(); });
    $('#go').onclick = () => start(c);
    $('#cont') && ($('#cont').onclick = () => { s = JSON.parse(localStorage.getItem(KEY)); render(); });
  };
  draw();
}
function start(c) {
  const r = (a, b) => a + Math.floor(Math.random() * (b - a));
  s = {name:c.name.trim(), av:c.av, color:c.color, traits:c.traits, age:18, money:5000, health:r(70,95), happiness:r(55,80), smarts:r(40,70), looks:r(40,75), social:r(35,65), job:null, college:0, school:0, ap:3, seen:[], log:[], dead:false};
  log(`${s.name} turns 18. The story begins.`, 'good'); save(); render();
}
function render() {
  if (!s) return create();
  const stat = ([k, n, col]) => `<div class="stat"><div>${n}<b>${s[k]}</b></div><div class="bar"><i style="width:${s[k]}%;background:${col}"></i></div></div>`;
  const acts = ACTIONS.map((a, i) => `<button data-a="${i}" ${s.ap < 1 || s.dead ? 'disabled' : ''}><span>${a.i}</span><span>${a.t}<small>${a.d}</small></span></button>`).join('');
  $('#app').innerHTML = `<div><section class="card"><div class="mut">AGE ${s.age}</div><h1>${s.dead ? 'A life well lived.' : 'What will you do this year?'}</h1>
    <div class="who"><div class="av" style="background:${s.color}">${s.av}</div><div><h2 style="margin:0">${s.name}</h2><div class="mut">${s.job ? s.job.t : 'Unemployed'} · ${eduLabel()}</div>${s.traits.map(t => `<span class="chip">${t}</span>`).join('')}</div></div>
    <div class="stats">${STATS.map(stat).join('')}</div>
    ${s.dead ? '<button class="primary age" id="again">Start a new life</button>' : '<button class="primary age" id="up">Age up to ' + (s.age + 1) + '</button>'}</section>
    <section class="card"><h2>Life story</h2><div class="log">${s.log.slice(0, 40).map(l => `<p class="${l.tone}"><span>${l.age}</span>${l.text}</p>`).join('')}</div></section></div>
    <div><section class="card"><h2>Your circumstances</h2>
    <div class="row"><span class="mut">Money</span><b class="${s.money < 0 ? 'bad' : 'good'}">${money(s.money)}</b></div>
    <div class="row"><span class="mut">Job</span><b>${s.job ? `${s.job.t} (${money(s.job.pay)}/yr)` : 'None'}</b></div>
    <div class="row"><span class="mut">Education</span><b>${eduLabel()}</b></div></section>
    <section class="card"><h2>Actions</h2><div class="ap">${[0,1,2].map(i => `<div class="pip ${i < s.ap ? '' : 'off'}"></div>`).join('')}<span class="mut">${s.ap} left this year</span></div>
    <div class="acts">${acts}
    <button data-a="job" ${s.ap < 1 || s.dead ? 'disabled' : ''}><span>💼</span><span>${s.job ? 'Quit your job' : 'Look for a job'}<small>${s.job ? 'Free action' : 'Costs 1 action'}</small></span></button>
    <button data-a="college" ${s.ap < 1 || s.dead || s.school || s.college || s.money < 8000 ? 'disabled' : ''}><span>🎓</span><span>Enroll in college<small>4 years · $8,000/yr · needs $8,000 saved</small></span></button></div></section></div>`;
  document.querySelectorAll('[data-a]').forEach(b => b.onclick = () => act(b.dataset.a));
  $('#up') && ($('#up').onclick = ageUp); $('#again') && ($('#again').onclick = () => { s = null; create(); });
  save();
}
function act(k) {
  if (k === 'job') return s.job ? (log(`You quit your job as ${s.job.t}.`), s.job = null, render()) : jobList();
  if (k === 'college') { s.ap--; s.school = 4; log('You enrolled in college.', 'good'); return render(); }
  const a = ACTIONS[k]; s.ap--;
  let txt;
  if (a.run) txt = a.run();
  else { const f = {...a.fx}; if (a.trait && has(a.trait[0])) f[a.trait[1]] += 3; txt = `${a.m} (${fx(f)})`; }
  log(txt); render();
}
function jobList() {
  const ok = j => (!j.req.health || s.health >= j.req.health) && (!j.req.smarts || s.smarts >= j.req.smarts) && (!j.req.social || s.social >= j.req.social) && (!j.req.college || s.college);
  const need = j => Object.entries(j.req).map(([k, v]) => k === 'college' ? 'college degree' : `${k} ${v}+`).join(', ') || 'no requirements';
  modal('<h2>Job openings</h2><p class="mut">Applying costs 1 action and is not guaranteed.</p>', JOBS.map(j => ({
    t: `${ok(j) ? '' : '🔒 '}${j.t} · ${money(j.pay)}/yr <small class="mut">(${need(j)})</small>`,
    cb: () => { if (!ok(j)) { modal('<h2>Not qualified yet</h2><p>You need: ' + need(j) + '.</p>', closeBtn); return; } s.ap--;
      if (chance(.55 + (s.smarts + s.social) / 500, 1)) { s.job = {t: j.t, pay: j.pay}; log(`You were hired as a ${j.t}!`, 'good'); } else log(`You applied to be a ${j.t} but were turned down.`, 'bad'); render(); }
  })).concat([{t: 'Cancel'}]));
}
function yearly() {
  const n = [], cost = has('Frugal') ? 8000 : 10000; s.money -= cost; n.push(`living −${money(cost)}`);
  if (s.job) { s.money += s.job.pay; n.push(`salary +${money(s.job.pay)}`); if (chance(.2, 1)) { const r = Math.round(s.job.pay * .07); s.job.pay += r; log(`You got a raise of ${money(r)}!`, 'good'); } }
  if (s.school) { s.school--; s.money -= 8000; s.smarts = clamp(s.smarts + 3); n.push('tuition −$8,000'); if (!s.school) { s.college = 1; log('You graduated from college!', 'good'); } }
  if (s.age > 35) fx({health: -(has('Athletic') ? 1 : 2) - (s.age > 55 ? 1 : 0)});
  if (s.age > 40) fx({looks: -1});
  if (s.money < 0) { fx({happiness: -4}); n.push('debt stress'); }
  log(`Year summary: ${n.join(', ')}.`);
}
function ageUp() {
  s.age++; s.ap = 3; yearly();
  const pool = EVENTS.filter(e => (!e.min || s.age >= e.min) && (!e.job || s.job) && !s.seen.includes(e.text) && (!e.rare || chance(.15)));
  if (s.health <= 0 || (s.age >= 65 && Math.random() < (s.age - 64) * .015 + (s.health < 30 ? .1 : 0)) || s.age >= 105) return die();
  if (pool.length && Math.random() < .85) event(pool[Math.floor(Math.random() * pool.length)]); else render();
}
function event(e) {
  s.seen = [...s.seen.slice(-6), e.text];
  modal(`<div class="mut">AGE ${s.age}</div><h2>${e.text}</h2>`, e.choices.map(c => ({t: c.t, cb: () => {
    let o = c, alt = c.r && chance(c.r.p, c.r.good);
    if (alt) o = c.r; const eff = fx(o.fx || {}); if (o.lose || (c.lose && !c.r)) s.job = null;
    const tone = alt ? (c.r.good ? 'good' : 'bad') : '';
    log(`${o.m}${eff ? ' (' + eff + ')' : ''}`, tone);
    modal(`<h2>${o.m}</h2><p class="${tone}">${eff || 'No change.'}</p>`, [{t: 'Continue', cb: () => s.health <= 0 ? die() : render()}]);
  }})));
}
function die() {
  s.dead = true; const nw = money(s.money);
  log(`${s.name} passed away at age ${s.age}.`, 'bad'); save();
  modal(`<h1>${s.name}, 18–${s.age}</h1><p>Final savings: <b>${nw}</b><br>Last job: ${s.job ? s.job.t : 'none'}<br>Education: ${eduLabel()}<br>Happiness at the end: ${s.happiness}</p>`, closeBtn);
}
$('#newBtn').onclick = () => modal('<h2>Start a new life?</h2><p class="mut">Your current life will be erased.</p>', [{t: 'Yes, start over', cb: () => { localStorage.removeItem(KEY); s = null; create(); }}, {t: 'Cancel'}]);
try { s = JSON.parse(localStorage.getItem(KEY)); } catch { s = null; }
s && s.dead ? (s = null, create()) : render();
})();
